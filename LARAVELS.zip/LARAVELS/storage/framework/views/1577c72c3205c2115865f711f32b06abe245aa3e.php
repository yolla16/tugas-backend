

<?php $__env->startSection('main'); ?>
<a href="<?php echo e(url("contacts/create")); ?>" class="btn btn-success mb-2">New</a>

<?php if(session()->get('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong><?php echo e(session()->get('success')); ?></strong>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

<div class="row">
    <form action="<?php echo e(url("/")); ?>" class="form-inline" method="GET">
        <div class="form-group mx-sm-3 mb-2">
            <input value="<?php echo e(Request::get('keyword')); ?>" name="keyword" type="text" class="form-control"
                placeholder="by name">
        </div>
        <button type="submit" class="btn btn-primary mb-2">Search</button>
    </form>
</div>

<div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th colspan="2">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contact->id); ?></td>
                    <td><?php echo e($contact->name); ?></td>
                    <td><?php echo e($contact->email); ?></td>
                    <td><?php echo e($contact->phone); ?></td>
                    <td><?php echo e($contact->address); ?></td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(url("contacts/{$contact->id}/edit")); ?>">EDIT</a>
                    </td>
                    <td>
                        <form action="<?php echo e(url("contacts/{$contact->id}")); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger">DELETE</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($contacts->links()); ?>

        <div>
            <a href="<?php echo e(route('logout')); ?>" class="btn btn-warning mt-5">Logout</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LARAVELS\resources\views/contact/index.blade.php ENDPATH**/ ?>