

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col-md-8 offset-sm-2">
        <h2 class="display-6">show</h2>
    </div>
</div>
<div class="row">
    <div class="col-md-8 offset-sm-2">
        <form action="<?php echo e(url("/contacts/{$contact->id}")); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="full_name">Full Name:</label>
                <?php echo e($contact->full_name); ?>

            </div>
            <div class="form-group">
                <label for="emial">Email:</label>
                <?php echo e($contact->email); ?>

            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <?php echo e($contact->phone); ?>

            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <?php echo e($contact->address); ?>

            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
        <a class="btn btn-warning mt-3" href="<?php echo e(url('/')); ?>">Cancel</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LARAVELS\resources\views/contact/show.blade.php ENDPATH**/ ?>